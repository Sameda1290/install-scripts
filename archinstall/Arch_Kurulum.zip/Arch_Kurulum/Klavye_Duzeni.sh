echo "Klavye düzeni ayarlanıyor..."

while true; do
    echo "Lütfen klavye düzeninizi seçin:"
    echo "1) Türkçe"
    echo "2) İngilizce"
    read -p "Seçiminizi yapın (1 veya 2): " choice

    case $choice in
        1)
            localectl set-x11-keymap tr
            localectl set-keymap trq
	    loadkeys trq
	    FONT=ter-v16b
            echo "Klavye düzeni Türkçe olarak ayarlandı."
            break
            ;;
        2)
	    loadkeys us
            localectl set-keymap us

            echo "Klavye düzeni İngilizce olarak ayarlandı."
            break
            ;;
        *)
            echo "Hatalı giriş! Lütfen 1 veya 2 tuşlarından birini seçin."
            ;;
    esac
done

read -p "Klavye düzeninizin doğru olduğundan emin misiniz? (E/H): " confirm

if [ "$confirm" == "E" ] || [ "$confirm" == "e" ]; then
    echo "Klavye düzeni başarıyla ayarlandı."
else
    echo "Klavye düzeni ayarı iptal edildi."
fi

