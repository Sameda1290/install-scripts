#!/bin/bash

# IP'den zaman dilimini al
timezone=$(curl -s https://ipinfo.io/timezone)

# Zaman dilimini kullanarak saat dilimini ayarla
ln -sf /usr/share/zoneinfo/$timezone /etc/localtime
hwclock -uw

# Ntp etkinleştirmek
timedatectl set-ntp 1
timedatectl set-timezone $timezone

# Saati göstermek
timedatectl status && clear && sleep 0.1 && sleep 1 && date 
echo "Saat Dilimi $timezone Olarak Ayarlandı. "
