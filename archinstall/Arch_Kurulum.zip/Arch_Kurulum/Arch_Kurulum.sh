#!/bin/bash

# Saat Ayarı 
./Saat_Ayari.sh

# Klavye Ayarı
./Klavye_Duzeni.sh

#Disk Ayarı
./Disk_Ayari.sh

#Pacman Ayarı
./Pacman_Ayari.sh

# Pacstrap Ayarı
./Pacstrap_Ayari.sh
