#!/bin/bash

# Tüm disk bölümlerini temizle ve EFI ve Arch Linux bölümlerini oluştur
sgdisk --zap-all --clear -n 1:0:+550MiB -c 1:EFI -t 1:ef00 -n 2:0:0 -c 2:ArchLinux -t 2:8309 "$selected_disk"

# EFI ve Arch Linux bölümlerini oluştur
if [[ "$selected_disk" == *"nvme"* ]]; then
    mkfs.vfat -F32 -n EFI "${selected_disk}p1"
    mkfs.btrfs -f -L ArchLinux "${selected_disk}p2"
else
    mkfs.vfat -F32 -n EFI "${selected_disk}1"
    mkfs.btrfs -f -L ArchLinux "${selected_disk}2"
fi


# Biçimlendirilmiş Btfs partitionunu subvolleri oluşturmak için mount etmek
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120 LABEL=ArchLinux /mnt

# /mnt dizinine girmek
cd /mnt
# @ btrfs subvolume oluşturmak
btrfs su cr @

# @/var btrfs subvolume oluşturmak
btrfs su cr @/var

# @/usr klasörünü oluşturmak
mkdir @/usr

# @/usr/local subvolume oluşturmak
btrfs su cr @/usr/local

# @/srv subvolume oluşturmak
btrfs su cr @/srv

# @/root subvolume oluşturmak
btrfs su cr @/root

# @/opt subvolume oluşturmak
btrfs su cr @/opt

# @/tmp subvolume oluşturmak
btrfs su cr @/tmp

# @/home subvolume oluşturmak
btrfs su cr @/home

# Ana dizine Dönmek
cd

# /mnt dizinini btrfs subvolumeleri ve subvolidler ile mount etmek için umount etmek
umount /mnt

# /mnt dizinini Pacstrap kısmına hazırlamak için subvollerin ve subvolidlerin mount edilmesi
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@,subvolid=256 LABEL=ArchLinux /mnt
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/var,subvolid=257 LABEL=ArchLinux /mnt/var
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/usr/local,subvolid=258 LABEL=ArchLinux /mnt/usr/local
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/srv,subvolid=259 LABEL=ArchLinux /mnt/srv
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/root,subvolid=260 LABEL=ArchLinux /mnt/root
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/opt,subvolid=261 LABEL=ArchLinux /mnt/opt
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/tmp,subvolid=262 LABEL=ArchLinux /mnt/tmp
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/home,subvolid=263 LABEL=ArchLinux /mnt/home
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/var/lib/portables,subvolid=264 LABEL=ArchLinux /mnt/var/lib/portables
mount -t btrfs -o defaults,rw,noatime,compress-force=zstd:2,ssd,discard=async,space_cache=v2,commit=120,subvol=@/var/lib/machines,subvolid=265 LABEL=ArchLinux /mnt/var/lib/machines



# EFI patitionu mount etmek
mount --mkdir -t vfat -o nodev,nosuid,noexec LABEL=EFI /mnt/boot/efi


# subvolumeleri listelemek
btrfs su l /mnt


# disk durumunu detaylı bir şekilde göstermek
lsblk -f
