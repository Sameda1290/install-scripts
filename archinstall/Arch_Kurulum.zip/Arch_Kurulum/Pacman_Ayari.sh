#!/bin/bash
#Dosya Yolu
cp /etc/pacman.conf /etc/pacman.conf.yedek

pacman_conf=/etc/pacman.conf
sed -i '39s/.*/DisableDownloadTimeout/' $pacman_conf
sed -i '39s/^$/DisableDownloadTimeout\n/; 39a\\' $pacman_conf
sed -i '38s/.*/ILoveCandy/' $pacman_conf
sed -i '37s/^#//' $pacman_conf
sed -i '36s/^#//' $pacman_conf
sed -i '33s/^#//' $pacman_conf
sed -i '32s/^#//' $pacman_conf
sed -i '97s/^#//' $pacman_conf
sed -i '92s/^#//' $pacman_conf
sed -i '91s/^#//' $pacman_conf
# Geri sayım için bir döngü başlat
for (( i=3; i>=1; i-- )); do
    echo "Pacman Konfigüre Ediliyor - Geri Sayım: $i"
    sleep 1  # 1 saniye bekleyin
done

# Son olarak, konfigürasyon tamamlandı mesajını göster
echo "Pacman Konfigüre Edildi. "

pacman-key --init
pacman-key --populate
pacman -S archlinux-keyring --needed --noconfirm
