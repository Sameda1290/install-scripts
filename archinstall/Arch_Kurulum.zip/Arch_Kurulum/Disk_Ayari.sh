#!/bin/bash

# Diskleri listele ve filtrele
disks=$(lsblk -dno NAME,SIZE | grep -E 'sd[a-z]|nvme[0-9]+n[0-9]+|vd[a-z]')

echo "Diski Seçiniz"
echo "$disks" | nl -s ') '

# Disk seçimini al
while :; do
    read -p "Lütfen kurulum yapmak istediğiniz diski seçin (1-$(echo "$disks" | wc -l)): " selection
    selected_disk=$(echo "$disks" | awk -v sel="$selection" 'NR==sel {print "/dev/" $1}')
    if [[ -n "$selected_disk" ]]; then
        break
    else
        echo "Hatalı giriş! Lütfen geçerli bir disk numarası girin."
    fi
done

echo "Seçilen Disk: $selected_disk"

# Formatlama işlemini yap
while :; do
    read -p "Diski formatlamak istiyor musunuz? (E/H): " format_option
    case "$format_option" in
        [Ee])
            echo "Disk formatlama işlemi başlatılıyor..."
            for i in {3..1}; do echo -ne "Kalan süre: $i\033[0K\r"; sleep 1; done
            wipefs -af "$selected_disk"
            echo "Disk formatlandı."
            break
            ;;
        [Hh])
            echo "Disk formatlama işlemi iptal edildi."
            exit 0
            ;;
        *)
            echo "Geçersiz seçenek! Lütfen 'E' veya 'H' girin."
            ;;
    esac
done

# Şifreleme isteğini al ve uygun script'i çalıştır
while :; do
    read -p "Diski şifrelemek istiyor musunuz? (E/H): " encrypt_option
    case "$encrypt_option" in
        [Ee])
            echo "Disk şifreleme seçeneği seçildi."
            # Burada şifreleme kodu eklenebilir
            ;;
        [Hh])
            echo "Disk şifreleme seçeneği seçilmedi."
	    export selected_disk
            ./Sifresiz_Disk_Opsiyonu.sh "$selected_disk"
            ;;
        *)
            echo "Hatalı giriş! Lütfen 'E' veya 'H' girin."
            ;;
    esac
    break
done

