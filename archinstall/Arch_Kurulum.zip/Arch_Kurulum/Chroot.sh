#!/bin/bash
setfont /usr/share/kbd/consolefonts/ter-v16b.psf.gz

sleep 2.5
clear
# IP'den zaman dilimini al
timezone=$(curl -s https://ipinfo.io/timezone)

# Zaman dilimini kullanarak saat dilimini ayarla
ln -sf /usr/share/zoneinfo/$timezone /etc/localtime
hwclock --systohc

# Kullanıcıdan hostname girdisini al
read -p "Yeni hostname'i girin: " new_hostname

# /etc/hostname dosyasını güncelle
echo "$new_hostname" | sudo tee /etc/hostname > /dev/null

# /etc/hosts dosyasını güncelle
echo -ne "
127.0.0.1       localhost
::1             localhost
127.0.0.1       $new_hostname.localdomain	$new_hostname
" >> /etc/hosts
echo "$new_hostname /etc/hosname dosyasına başarıyla eklendi."
echo "/etc/hosts dosyasi başarıyla düzenlendi"
sleep 2.5
clear


echo "en_US.UTF-8 UTF-8" >> /etc/locale.gen
echo "LANG=en_US.UTF-8" >> /etc/locale.conf
echo "LANGUAGE=en_US.UTF-8" >> /etc/locale.conf
echo "LOCALE=en_US.UTF-8" >> /etc/locale.conf
echo "LC_COLLATE=C" >> /etc/locale.conf

locale-gen

# Pacman config dosya yolu
pacman_conf=/etc/pacman.conf

pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com 
pacman-key --lsign-key 3056513887B78AEB 
pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst' --noconfirm
pacman -U 'https://cdn-mirror.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst' --noconfirm

sed -i '92 a\
' $pacman_conf 
sed -i '94s/.*/[chaotic-aur]/' $pacman_conf
sed -i '95s|.*|Include = /etc/pacman.d/chaotic-mirrorlist|' $pacman_conf
sed -i '95 a\
' $pacman_conf
curl https://mirror.cachyos.org/cachyos-repo.tar.xz -o cachyos-repo.tar.xz
tar xvf cachyos-repo.tar.xz && cd cachyos-repo && sed -i '/${mirror_url}\/pacman/ s/$/ --noconfirm/';sed -i '/pacman -Syu/ s/$/ --noconfirm/' cachyos-repo.sh;sed -i 's/\(${mirror_url}.*\.zst"\)/\1 --noconfirm/' cachyos-repo.sh
sudo ./cachyos-repo.sh

pacman-key --init
pacman-key --populate
pacman -Syyu

Chroot_Kullanici.sh

sleep 1.5

Sifresiz_Grub.sh
clear

echo "Sistemler Etkinleştiriliyor..."
systemctl enable NetworkManager
systemctl enable fstrim.timer
systemctl enable sshd
echo "Sistemler Etkinleştirildi."
sleep 1.5

rm /bin/Chroot.sh
