#!/bin/bash
sudo setfont /usr/share/kbd/consolefonts/ter-v16b.psf.gz

# Kullanıcı adı girişi için döngü
while true; do
    read -p "Yeni kullanıcı adını girin: " username

    # Kullanıcı adının uzunluğunu kontrol et
    if [ ${#username} -lt 1 ]; then
        echo "Hata: Geçersiz kullanıcı adı. Boş bırakılamaz."
    elif [[ "$username" =~ [^a-zA-Z0-9_] ]]; then
        echo "Hata: Kullanıcı adı yalnızca alfasayısal ve alt çizgi karakterlerinden oluşmalıdır."
    else
        # Kullanıcı adının zaten var olup olmadığını kontrol et
        if id "$username" &>/dev/null; then
            echo "Hata: '$username' adında bir kullanıcı zaten mevcut."
        else
            break
        fi
    fi
done

# Kullanıcı şifresi girişi için döngü
while true; do
    read -s -p "Kullanıcı şifresini girin: " user_password
    echo
    read -s -p "Şifreyi tekrar girin: " user_password_confirm
    echo

    # Parolaların eşleşip eşleşmediğini kontrol et
    if [ "$user_password" != "$user_password_confirm" ]; then
        echo "Hata: Parolalar eşleşmiyor. Lütfen tekrar deneyin."
    else
        break
    fi
done

# Root şifresi girişi için döngü
while true; do
    read -s -p "Root şifresini girin: " root_password
    echo
    read -s -p "Şifreyi tekrar girin: " root_password_confirm
    echo

    # Parolaların eşleşip eşleşmediğini kontrol et
    if [ "$root_password" != "$root_password_confirm" ]; then
        echo "Hata: Parolalar eşleşmiyor. Lütfen tekrar deneyin."
    else
        break
    fi
done

# Kullanıcıya root yetkisi verilsin mi?
read -p "Kullanıcıya root yetkisi verilsin mi? (E/H): " root_access

# Evet seçeneği seçilirse
if [ "$root_access" == "E" ] || [ "$root_access" == "e" ]; then
    sudo sed -i '/^#\s*%wheel\s*ALL=(ALL:ALL)\s*ALL/s/^#\s*//' /etc/sudoers
    echo "Defaults rootpw" >> /etc/sudoers
fi

# Kullanıcı oluşturma komutu
sudo useradd -m -G wheel -s /usr/bin/zsh "$username"
cp /root/.zshrc /home/$username
cp /root/.zprofile /home/$username

chsh -s /usr/bin/zsh 
chsh -s /usr/bin/zsh $username

# Kullanıcı ve root şifrelerini ayarla
echo "$username:$user_password" | sudo chpasswd
echo "root:$root_password" | sudo chpasswd

if [ $? -eq 0 ]; then
    echo "Kullanıcı '$username' başarıyla oluşturuldu."
else
    echo "Hata: Kullanıcı oluşturulurken bir sorun oluştu."
fi
