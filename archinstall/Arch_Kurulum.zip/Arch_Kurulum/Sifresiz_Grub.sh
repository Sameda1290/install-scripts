#!/bin/bash

sed -i "s|^HOOKS=.*|HOOKS=(base udev autodetect microcode modconf kms keyboard keymap consolefont block filesystems btrfs fsck)|g" /etc/mkinitcpio.conf
sed -i "s|^BINARIES=.*|BINARIES=(\"/usr/bin/btrfs\")|g" /etc/mkinitcpio.conf
sed -i '/#COMPRESSION="lz4"/s/^#//g' /etc/mkinitcpio.conf
sed -i "s|^#COMPRESSION_OPTIONS=.*|#COMPRESSION_OPTIONS=(-9)|g" /etc/mkinitcpio.conf
sed -i '/#COMPRESSION_OPTIONS=(-9)/s/^#//g' /etc/mkinitcpio.conf

# Grub için gereken paketlerin kurulması
pacman -Syyu linux-cachyos-bore-lto linux-cachyos-bore-lto-headers grub efibootmgr dosfstools mtools os-prober efitools --noconfirm --needed

# Kullanıcıdan bootloader-id girdisini al

# Yeni parametreleri oluştur
new_params="nowatdcdog nvme_load=YES zswap.enabled=0 loglevel=3"

# sed komutuyla GRUB_CMDLINE_LINUX_DEFAULT satırını güncelle
sudo sed -i "/^GRUB_CMDLINE_LINUX_DEFAULT=/ s/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT=\"$new_params\"/" /etc/default/grub

# Grub kurulumu
grub-install --target x86_64-efi --efi-directory /boot/efi --boot-directory /boot
grub-mkconfig -o /boot/grub/grub.cfg

echo "Grub kurulumu tamamlandı. "

clear
sleep 1.5

neofetch

sleep 2

umount -R /mnt

rm /bin/Sifresiz_Grub.sh
