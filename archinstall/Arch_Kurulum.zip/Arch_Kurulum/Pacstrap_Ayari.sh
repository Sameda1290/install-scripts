#!/bin/bash

# İşlemcinin modelini al
cpu_vendor=$(grep vendor_id /proc/cpuinfo | awk 'NR==1{print $3}')

# İşlemcinin modeline göre uygun mikro kod paketini seç
if [ "$cpu_vendor" == "GenuineIntel" ]; then
    ucode_package="intel-ucode"
elif [ "$cpu_vendor" == "AuthenticAMD" ]; then
    ucode_package="amd-ucode"
else
    echo "Desteklenmeyen işlemci modeli."
    exit 1
fi

# Uygun mikro kod paketini yükle
echo "İşlemci modeli: $cpu_vendor"
echo "Uygun mikro kod paketi: $ucode_package"

pacstrap -K /mnt $ucode_package btrfs-progs base base-devel linux-firmware linux-api-headers linux-headers xdg-user-dirs xorg xorg-xinit xorg-appres sysfsutils xorg-xwayland wayland-utils xorg-xauth vim nano p7zip unzip unrar zip udisks2 gvfs-afc gvfs-mtp gvfs-gphoto2 gphoto2 sudo mkinitcpio git wget curl networkmanager openssh mlocate neofetch inxi zsh noto-fonts ttf-dejavu ttf-dejavu-nerd ttf-roboto ttf-roboto-mono ttf-roboto-mono-nerd terminus-font gnu-free-fonts noto-fonts noto-fonts-emoji noto-fonts-extra ttf-font-awesome ttf-jetbrains-mono ttf-jetbrains-mono-nerd ttf-liberation ttf-liberation-mono-nerd ttf-nerd-fonts-symbols-mono ttf-nerd-fonts-symbols-common ttf-roboto ttf-roboto-mono ttf-roboto-mono-nerd awesome-terminal-fonts ttf-font-awesome otf-font-awesome pipewire pipewire-pulse pipewire-alsa pipewire-audio pipewire-jack lib32-pipewire lib32-pipewire-jack wireplumber alsa-tools alsa-utils alsa-firmware --noconfirm --needed

cp /etc/zsh/zshrc /mnt/root/.zshrc
cp /etc/zsh/zprofile /mnt/root/.zprofile

cp /etc/pacman.conf.yedek /mnt/etc/pacman.conf.yedek
cp /etc/pacman.conf /mnt/etc/pacman.conf

cp /mnt/etc/mkinitcpio.conf /mnt/etc/mkinitcpio.yedek

genfstab -LUp /mnt >> /mnt/etc/fstab
cat /mnt/etc/fstab

cp /root/Arch_Kurulum/Chroot.sh /mnt/bin
cp /root/Arch_Kurulum/Chroot_Kullanici.sh /mnt/bin
cp /root/Arch_Kurulum/Sifresiz_Grub.sh /mnt/bin
cp /etc/vconsole.conf	/mnt/etc/vconsole.conf
arch-chroot /mnt /usr/bin/zsh -c "Chroot.sh"
